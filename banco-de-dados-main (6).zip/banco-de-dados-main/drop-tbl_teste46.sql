drop table `tbl_teste46`;
