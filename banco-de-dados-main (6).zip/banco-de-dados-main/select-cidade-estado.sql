select * from `cidade`,`estado` where `cidade`.`nome` like '%rio%' and `cidade`.`uf` = `estado`.`id`;
