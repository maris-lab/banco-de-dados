create schema `db_curso_java`;
create schema `db_senac`;